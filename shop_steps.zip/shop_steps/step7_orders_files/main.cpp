#include "Shop.h"

int main() {
    Shop shop(1, "Sharma General Store", "Civil Lines");
    string err;
    shop.addStock(101, "Milk 500ml", 30, 20, err);
    shop.receiveOrder(1, 101, 5, err);
    shop.receiveOrder(2, 101, 3, err);
    shop.acceptNext(err);
    shop.packNext(err);
    int oid;
    if (shop.handToDispatch(oid, err)) cout << "Order #" << oid << " dispatched\n";
    shop.rejectNext(err);                      // order 2 rejected, stock released
    shop.desk.display();
    shop.viewStock();
    shop.save("inventory.txt");
    Shop s2(2, "Reload", "Civil Lines");
    s2.load("inventory.txt");
    s2.viewStock();
    return 0;
}
