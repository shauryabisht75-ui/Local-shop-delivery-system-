#pragma once
#include <fstream>
#include <sstream>
#include <vector>
#include "InventoryTable.h"
#include "OrderDesk.h"

class Shop {
public:
    int shopId;
    string name;
    string area;
    InventoryTable inventory;
    NameTable names;
    OrderDesk desk;

    Shop(int id = 0, string n = "", string a = "") : shopId(id), name(n), area(a) {}

    // ================= STOCK =================
    bool addStock(int pid, const string &pname, double price, int qty, string &err) {
        if (pid <= 0)           { err = "Product id must be positive"; return false; }
        if (!validName(pname))  { err = "Invalid product name"; return false; }
        if (price <= 0)         { err = "Price must be positive"; return false; }
        if (qty < 0)            { err = "Quantity cannot be negative"; return false; }
        if (inventory.find(pid)) { err = "Product id already exists"; return false; }
        if (names.find(pname) != -1) { err = "Product name already exists"; return false; }
        inventory.insert(pid, pname, price, qty);
        names.insert(pname, pid);
        return true;
    }
    bool updateStock(int pid, double newPrice, int newQty, string &err) {
        StockNode *n = inventory.find(pid);
        if (!n)            { err = "Product not found"; return false; }
        if (newPrice <= 0) { err = "Price must be positive"; return false; }
        if (newQty < 0)    { err = "Quantity cannot be negative"; return false; }
        n->price = newPrice;
        n->qty = newQty;
        return true;
    }
    bool deleteStock(int pid, string &err) {
        StockNode *n = inventory.find(pid);
        if (!n) { err = "Product not found"; return false; }
        names.remove(n->name);
        inventory.remove(pid);
        return true;
    }
    void viewStock() const {
        cout << "Stock of " << name << " (" << area << "):\n";
        if (inventory.size() == 0) { cout << "  (no products)\n"; return; }
        inventory.forEach([](StockNode *n) { printNode(n); });
    }

    // ================= SEARCH =================
    // O(1) average exact lookup through the name hash table
    StockNode *findByName(const string &pname) const {
        int id = names.find(pname);
        return id == -1 ? nullptr : inventory.find(id);
    }
    // partial match (case-insensitive substring)
    int searchPartial(const string &text) const {
        string t = toLower(text);
        int found = 0;
        inventory.forEach([&](StockNode *n) {
            if (toLower(n->name).find(t) != string::npos) { printNode(n); found++; }
        });
        return found;
    }

    // ================= SORTING =================
    // Insertion sort by price
    void viewSortedByPrice(bool ascending = true) const {
        vector<StockNode *> a = toArray();
        for (size_t i = 1; i < a.size(); i++) {
            StockNode *key = a[i];
            int j = (int)i - 1;
            while (j >= 0 && (ascending ? a[j]->price > key->price : a[j]->price < key->price)) {
                a[j + 1] = a[j]; j--;
            }
            a[j + 1] = key;
        }
        cout << "Stock sorted by price (" << (ascending ? "low to high" : "high to low") << "):\n";
        for (StockNode *n : a) printNode(n);
        if (a.empty()) cout << "  (no products)\n";
    }
    // Bubble sort by quantity (lowest first)
    void viewSortedByQty() const {
        vector<StockNode *> a = toArray();
        for (size_t i = 0; i + 1 < a.size(); i++)
            for (size_t j = 0; j + 1 < a.size() - i; j++)
                if (a[j]->qty > a[j + 1]->qty) swap(a[j], a[j + 1]);
        cout << "Stock sorted by quantity (lowest first):\n";
        for (StockNode *n : a) printNode(n);
        if (a.empty()) cout << "  (no products)\n";
    }
    int lowStock(int threshold) const {
        int c = 0;
        cout << "Low stock (qty <= " << threshold << "):\n";
        inventory.forEach([&](StockNode *n) { if (n->qty <= threshold) { printNode(n); c++; } });
        if (!c) cout << "  none\n";
        return c;
    }

    // ================= ORDER DESK =================
    // Stock is reserved at order time so the last item cannot be sold twice.
    bool receiveOrder(int orderId, int pid, int qty, string &err) {
        StockNode *n = inventory.find(pid);
        if (!n)           { err = "Product not found"; return false; }
        if (qty <= 0)     { err = "Invalid quantity"; return false; }
        if (n->qty < qty) { err = "Not enough stock"; return false; }
        n->qty -= qty;
        desk.enqueue(orderId, pid, qty);
        return true;
    }
    bool acceptNext(string &err) {
        DeskOrder *o = desk.peek();
        if (!o || o->status != "PLACED") { err = "No order waiting to be accepted"; return false; }
        o->status = "ACCEPTED"; return true;
    }
    bool packNext(string &err) {
        DeskOrder *o = desk.peek();
        if (!o || o->status != "ACCEPTED") { err = "Front order is not accepted yet"; return false; }
        o->status = "PACKED"; return true;
    }
    bool rejectNext(string &err) {
        DeskOrder *o = desk.peek();
        if (!o || o->status != "PLACED") { err = "No order waiting"; return false; }
        StockNode *n = inventory.find(o->productId);
        if (n) n->qty += o->qty;                 // release reserved stock
        desk.dequeue(); return true;
    }
    bool handToDispatch(int &orderId, string &err) {
        DeskOrder *o = desk.peek();
        if (!o || o->status != "PACKED") { err = "Front order is not packed yet"; return false; }
        orderId = o->orderId;
        desk.dequeue(); return true;
    }

    // ================= FILE STORAGE =================
    bool save(const string &path) const {
        ofstream f(path);
        if (!f) return false;
        inventory.forEach([&](StockNode *n) {
            f << n->productId << '|' << n->name << '|' << n->price << '|' << n->qty << '\n';
        });
        return true;
    }
    bool load(const string &path) {
        ifstream f(path);
        if (!f) return false;
        inventory.clear();
        names.clear();
        string line;
        while (getline(f, line)) {
            stringstream ss(line);
            string a, b, c, d;
            getline(ss, a, '|'); getline(ss, b, '|'); getline(ss, c, '|'); getline(ss, d, '|');
            if (isNumber(a) && isPrice(c) && isNumber(d) && validName(b)) {
                if (inventory.insert(stoi(a), b, stod(c), stoi(d))) names.insert(b, stoi(a));
            }
        }
        return true;
    }

private:
    static void printNode(StockNode *n) {
        cout << "  [" << n->productId << "] " << n->name
             << "  Rs." << n->price << "  qty " << n->qty << "\n";
    }
    vector<StockNode *> toArray() const {
        vector<StockNode *> a;
        inventory.forEach([&](StockNode *n) { a.push_back(n); });
        return a;
    }
};
