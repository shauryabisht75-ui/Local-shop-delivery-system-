#include "Product.h"

int main() {
    Product p(101, "Milk 500ml", "Dairy");
    p.display();
    cout << isNumber("123") << isNumber("12a") << " "
         << isPrice("40.5") << isPrice("4.0.5") << " "
         << validName("Milk 500ml") << validName("Bad@Name") << "\n";
    return 0;
}
