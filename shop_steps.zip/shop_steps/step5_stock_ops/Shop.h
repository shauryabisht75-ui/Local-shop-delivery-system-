#pragma once
#include <fstream>
#include <sstream>
#include <vector>
#include "InventoryTable.h"
#include "OrderDesk.h"

class Shop {
public:
    int shopId;
    string name;
    string area;
    InventoryTable inventory;
    NameTable names;
    OrderDesk desk;

    Shop(int id = 0, string n = "", string a = "") : shopId(id), name(n), area(a) {}

    // ================= STOCK =================
    bool addStock(int pid, const string &pname, double price, int qty, string &err) {
        if (pid <= 0)           { err = "Product id must be positive"; return false; }
        if (!validName(pname))  { err = "Invalid product name"; return false; }
        if (price <= 0)         { err = "Price must be positive"; return false; }
        if (qty < 0)            { err = "Quantity cannot be negative"; return false; }
        if (inventory.find(pid)) { err = "Product id already exists"; return false; }
        if (names.find(pname) != -1) { err = "Product name already exists"; return false; }
        inventory.insert(pid, pname, price, qty);
        names.insert(pname, pid);
        return true;
    }
    bool updateStock(int pid, double newPrice, int newQty, string &err) {
        StockNode *n = inventory.find(pid);
        if (!n)            { err = "Product not found"; return false; }
        if (newPrice <= 0) { err = "Price must be positive"; return false; }
        if (newQty < 0)    { err = "Quantity cannot be negative"; return false; }
        n->price = newPrice;
        n->qty = newQty;
        return true;
    }
    bool deleteStock(int pid, string &err) {
        StockNode *n = inventory.find(pid);
        if (!n) { err = "Product not found"; return false; }
        names.remove(n->name);
        inventory.remove(pid);
        return true;
    }
    void viewStock() const {
        cout << "Stock of " << name << " (" << area << "):\n";
        if (inventory.size() == 0) { cout << "  (no products)\n"; return; }
        inventory.forEach([](StockNode *n) { printNode(n); });
    }

private:
    static void printNode(StockNode *n) {
        cout << "  [" << n->productId << "] " << n->name
             << "  Rs." << n->price << "  qty " << n->qty << "\n";
    }
    vector<StockNode *> toArray() const {
        vector<StockNode *> a;
        inventory.forEach([&](StockNode *n) { a.push_back(n); });
        return a;
    }
};
