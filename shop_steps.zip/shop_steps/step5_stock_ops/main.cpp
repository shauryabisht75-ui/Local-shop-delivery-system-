#include "Shop.h"

int main() {
    Shop shop(1, "Sharma General Store", "Civil Lines");
    string err;
    shop.addStock(101, "Milk 500ml", 30, 20, err);
    shop.addStock(102, "Bread", 40, 10, err);
    if (!shop.addStock(101, "Dup", 5, 1, err)) cout << "Error: " << err << "\n";
    shop.updateStock(102, 45, 12, err);
    shop.deleteStock(101, err);
    shop.viewStock();
    return 0;
}
