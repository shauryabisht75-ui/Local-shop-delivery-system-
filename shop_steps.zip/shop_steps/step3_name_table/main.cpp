#include "InventoryTable.h"

int main() {
    NameTable n;
    n.insert("Milk 500ml", 101);
    n.insert("Bread", 102);
    cout << "milk 500ML -> " << n.find("milk 500ML") << "\n";
    n.remove("Bread");
    cout << "bread -> " << n.find("Bread") << "\n";
    return 0;
}
