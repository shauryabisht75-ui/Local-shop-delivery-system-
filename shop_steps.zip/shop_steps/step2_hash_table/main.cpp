#include "InventoryTable.h"

int main() {
    InventoryTable t;
    t.insert(101, "Milk 500ml", 30, 20);
    t.insert(132, "Bread", 40, 10);          // same bucket as 101 (collision)
    cout << "size: " << t.size() << "\n";
    cout << "find 132: " << (t.find(132) ? t.find(132)->name : "none") << "\n";
    t.remove(101);
    cout << "after remove, find 101: " << (t.find(101) ? "found" : "none") << "\n";
    return 0;
}
