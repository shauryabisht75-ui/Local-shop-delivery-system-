#include "OrderDesk.h"

int main() {
    OrderDesk d;
    d.enqueue(1, 101, 5);
    d.enqueue(2, 102, 3);
    d.display();
    d.dequeue();                              // order 1 leaves first (FIFO)
    d.display();
    return 0;
}
