#include "Shop.h"

int main() {
    Shop shop(1, "Sharma General Store", "Civil Lines");
    string err;
    shop.addStock(101, "Milk 500ml", 30, 20, err);
    shop.addStock(102, "Bread", 45, 3, err);
    shop.addStock(103, "Eggs 12", 90, 8, err);
    shop.searchPartial("mil");
    shop.viewSortedByPrice(false);
    shop.viewSortedByQty();
    shop.lowStock(5);
    return 0;
}
